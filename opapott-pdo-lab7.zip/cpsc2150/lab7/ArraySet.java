/*
    Olivia Papotto
    Phillip Do
 */
package cpsc2150.lab7;

/**
 *
 * @invariant arr.getSize() >= 0
 */
public class ArraySet<T> extends SetAbs<T> implements ISet<T>{

    private static int MAX_SIZE = 100;
    private Object[] arr;
    private int size;

    /**
     * @post ArraySet()
     */
    public ArraySet(){
        arr = new Object[MAX_SIZE];
        size = 0;
    }

    public void add(Object val) {

        if(val instanceof Integer){

            if(this.isEmpty()){
                arr[getSize()] = val;
                size++;
            }

        }else if(val instanceof Double) {
            for (int i = 0; i < getSize(); i++) {
                if (arr[i] == null) {
                    arr[i] = (Double) val;
                    size++;
                    break;
                }
            }
        }
    }

    public T removePos(int pos) {

        Object removed = arr[pos];

        for(int i = pos; i < getSize() - 1; i++){
            arr[i] = arr[i + 1];
        }
        size--;

        return (T) removed;

    }

    public boolean contains(T val) {

        for(int i = 0; i < getSize(); i++){
            if(arr[i] == val)return true;
        }

        return false;

    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty(){
        if(getSize()-1 < MAX_SIZE)return true;
        else return false;
    }

}
