/*
    Olivia Papotto
    Phillip Do
 */
package cpsc2150.lab7;

import java.util.*;

public interface ISet<T> {

    /**
     *
     * @param val is the value to be
     *            added to the set
     * @pre
     * MIN_VALUE < val < MAX_VALUE
     * @post
     * MIN_VALUE < val < MAX_VALUE
     */
    void add(T val);

    /**
     *
     * @param pos is a position in the set
     * @return the value removed
     * @pre
     * pos > 0 && getSize() != 0
     * @post
     *
     */
    T removePos(int pos);

    /**
     *
     * @param val, a value supposedly in set
     * @return returns true if int val is
     *         present in the set
     * @pre
     * val is a valid input int
     * @post
     * true or false will be returned
     */
    boolean contains(T val);

    /**
     *
     * @return returns the size of the set
     * @pre
     * none
     * @post
     * 0 <= return <= 100
     */
    int getSize();

    /**
     * @pre unionWith.size() != 0
     * @post unionWith.size >= 1
     */
    default void union(ISet<T> unionWith){

        for(int i = unionWith.getSize(); i > 0; i-- ){
            T temp = unionWith.removePos(0);
            if(!this.contains(temp)){
                this.add(temp);
            }
        }

    }

    /**
     * @pre intWith.size() != 0
     * @post unionWith.size >= 1
     */
    default void intersect(ISet<T> intWith){

        List<T> temp1 = new ArrayList<>(); //holds this set
        List<T> temp2 = new ArrayList<>(); //holds diffWith set

        //copying both sets to a ArrayList
        for(int i = this.getSize(); i > 0; i-- ){
            T temp = this.removePos(0);
            temp1.add(temp);
        }
        for(int i = intWith.getSize(); i > 0; i-- ){
            T temp = intWith.removePos(0);
            temp2.add(temp);
        }

        //walk thru temp1, if temp2 doesn't contain the elements then add back to this
        for(int i = 0; i < temp1.size(); i++){
            if(temp2.contains(temp1.get(i))){
                this.add(temp1.get(i));
            }
        }

        //put elements back into diffWith
        //why? IDK but the diffWith will be deleted unless so
        for(T elements : temp2){
            intWith.add(elements);
        }


    }

    /**
     * @pre diffWith.size() >= 0
     * @post diffWith.size() >= 1
     */
    default void difference(ISet<T> diffWith){

        /* temp list contains values inside 'this', but not in diffWith.
           get the values, then delete from this then add all elements of
           temp list to this.
         */

        List<T> temp1 = new ArrayList<>(); //holds this set
        List<T> temp2 = new ArrayList<>(); //holds diffWith set

        //copying both sets to a ArrayList
        for(int i = this.getSize(); i > 0; i-- ){
            T temp = this.removePos(0);
            temp1.add(temp);
        }
        for(int i = diffWith.getSize(); i > 0; i-- ){
            T temp = diffWith.removePos(0);
            temp2.add(temp);
        }

        //walk thru temp1, if temp2 doesn't contain the elements then add back to this
        for(int i = 0; i < temp1.size(); i++){
            if(!temp2.contains(temp1.get(i))){
                this.add(temp1.get(i));
            }
        }

        //put elements back into diffWith
        for(T elements : temp2){
            diffWith.add(elements);
        }


    }

}
