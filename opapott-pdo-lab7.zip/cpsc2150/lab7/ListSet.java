/*
    Olivia Papotto
    Phillip Do
 */
package cpsc2150.lab7;

import java.util.*;

/**
 *
 * @invariant listset.getSize() >= 0
 */
public class ListSet<T> extends SetAbs<T> implements ISet<T> {

    private List<T> listset;

    /**
     * @post ListSet()
     */
    ListSet() {
        listset = new ArrayList<T>();
    }

    public void add(T val) {
        listset.add(val);
    }

    public T removePos(int pos) {

        T num = listset.get(pos);
        listset.remove(pos);

        return num;

    }

    public boolean contains(T val) {

        for (int i = 0; i < listset.size(); i++) {
            T num = listset.get(i);

            if (num == val) {
                return true;
            }

        }
        return false;

    }

    public int getSize() {
        return listset.size();
    }

    public boolean isEmpty() {
        return listset.isEmpty();
    }

}