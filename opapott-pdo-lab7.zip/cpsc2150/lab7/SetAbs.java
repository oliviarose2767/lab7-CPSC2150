/*
    Olivia Papotto
    Phillip Do
 */
package cpsc2150.lab7;

import java.util.*;

public abstract class SetAbs<T> implements ISet<T>{

    public abstract void add(T val);

    public abstract T removePos(int pos);

    public abstract boolean contains(T val);

    public abstract int getSize();

    /**
     *
     * @return formatted string containing contents of array or list
     */
    public String toString(){

        String s = new String();
        //use a list to temporary store values in this
        List<T> tempList = new ArrayList<>();

        //add elements in this to tempList
        for(int i = this.getSize(); i > 0; i--){
            T temp = this.removePos(0);
            tempList.add(temp);
        }


        //put tempArr elements back in this and add to String s
        for(int i = 0; i < tempList.size(); i++){
            if(tempList.get(i)== null)break;
            this.add(tempList.get(i));
            s += tempList.get(i) + ", ";
        }

        return s;

    }

    /**
     *
     * @param o is any object (list or array) with
     *          valid input
     * @return true IFF Object o equals 'this' or
     *         false IFF Object o does not equal 'this'
     */
    public boolean equals(Object o){

        if(!(o instanceof ISet)){return false;}
        else{
            ISet<T> temp = (ISet<T>) o; //cast as ISet<T>

            if(temp.getSize() != this.getSize())return false;
            else{
                //use contains to find if the two ISets are the same.
                for(int i = 0; i <temp.getSize();i++){
                    T value = temp.removePos(i);
                    if(!this.contains(value)){return false;}
                }
            }

            return true;

        }

    }


}
