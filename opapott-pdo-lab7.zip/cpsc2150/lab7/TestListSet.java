package cpsc2150.lab7;

import org.junit.Test;
import static org.junit.Assert.*;

public class TestListSet {

    private ISet<Integer> MakeASet(){
        ISet<Integer> test = new ListSet<>();
        return test;
    }

    @Test
    public void test_Add_Size(){
        ISet<Integer> test = MakeASet();
        test.add(32);
        int size = 1;
        assertTrue(test.getSize() == size);
    }

    @Test
    public void test_Add_Remove(){
        ISet<Integer> test = MakeASet();
        test.add(44);
        int num = 44;
        assertTrue(test.removePos(0) == num);
    }

    @Test
    public void test_Add_Routine(){
        ISet<Integer> test = MakeASet();
        int[] arr = {1,2,3};
        for(int i = 1; i <= 3; i++){
            test.add(i);
        }
        for(int i = 0; i < 3; i++){
            assertTrue(arr[i] == test.removePos(0));
        }
    }

    @Test
    public void test_Contains_Boundary(){
        ISet<Integer> test = MakeASet();
        test.add(5);
        int num = 5;
        assertTrue(test.contains(num));
    }

    @Test
    public void test_Contains_Routine(){
        ISet<Integer> test = MakeASet();
        test.add(16);
        int num = 15;
        assertTrue(!test.contains(num));
    }

    @Test
    public void test_Contains_Multi(){
        ISet<Integer> test = MakeASet();
        for(int i = 0; i < 10; i++){
            test.add(i);
        }
        assertTrue(test.contains(5));
    }

    @Test
    public void test_Equals_Boundary(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        for(int i = 1; i <= 3; i++){
            test1.add(i);
            test2.add(i);
        }
        assertTrue(test1.equals(test2));
    }

    @Test
    public void test_Equals_Routine(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        for(int i = 1; i <= 3; i++){
            test1.add(i);
            test2.add(i + 1);
        }
        assertTrue(!test1.equals(test2));
    }

    @Test
    public void test_Equals_Diff_Size(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        for(int i = 0; i < 6; i++){
            test1.add(i);
        }
        for(int i = 0; i < 5; i++){
            test2.add(i);
        }
        assertTrue(!test1.equals(test2));
    }

    @Test
    public void test_Union_Routine(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();

        for(int i = 1, j = 4; i <= 3; i++, j++){
            test1.add(i);
            test2.add(j);
        }

        test1.union(test2);

        //solution test
        ISet<Integer> test3 = MakeASet();
        for(int i = 1; i <= 6; i++){
            test3.add(i);
        }

        //assertTrue(test1.equals(test3));
        assertEquals(test1, test3);

    }

    @Test
    public void test_Union_Overlap(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        ISet<Integer> test3 = MakeASet();

        test1.add(2);
        test1.add(4);
        test1.add(6);
        test1.add(10);
        test1.add(11);

        test2.add(2);
        test2.add(4);
        test2.add(6);
        test2.add(9);
        test2.add(10);

        test3.add(2);
        test3.add(4);
        test3.add(6);
        test3.add(9);
        test3.add(10);
        test3.add(11);

        test3.toString();

        test1.union(test2);

        assertTrue(test1.equals(test3));
    }

    @Test
    public void test_Union_Boundary_DNE(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        ISet<Integer> expected = MakeASet();

        test1.add(1);
        test2.add(5);

        expected.add(6);

        test1.union(test2);

        assertTrue(!test1.equals(expected));

    }

    @Test
    public void test_Intersect_Routine(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        ISet<Integer> test3 = MakeASet();

        test1.add(1);
        test1.add(2);
        test1.add(3);
        test1.add(4);

        test2.add(3);
        test2.add(4);
        test2.add(5);
        test2.add(6);

        test3.add(3);
        test3.add(4);

        test1.intersect(test2);

        assertTrue(test3.equals(test1));
    }

    @Test
    public void test_Intersect_Diff(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        ISet<Integer> test3 = MakeASet();

        test1.add(1);
        test1.add(2);
        test1.add(3);
        test1.add(4);

        test2.add(0);


        test1.intersect(test2);

        assertTrue(test1.equals(test3));
    }

    @Test
    public void test_Intersect_Size(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        ISet<Integer> test3 = MakeASet();

        test1.add(2);
        test1.add(4);
        test1.add(6);
        test1.add(8);

        test2.add(6);
        test2.add(8);
        test2.add(10);
        test2.add(12);

        //expected
        test3.add(6);
        test3.add(8);

        test1.intersect(test2);

        assertTrue(test1.equals(test3) && test1.getSize() == 2);


    }

    @Test
    public void test_Difference_Boundary(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        ISet<Integer> test3 = MakeASet();

        //{1,2,3} - {2,3} = {1}

        test1.add(1);
        test1.add(2);
        test1.add(3);

        test2.add(2);
        test2.add(3);

        test3.add(1);

        test1.difference(test2); //Solution


        assertTrue(test1.equals(test3));
    }

    @Test
    public void test_Difference_Diff_Size(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        ISet<Integer> test3 = MakeASet();

        test2.add(2);
        test2.add(3);

        test1.difference(test2); //Solution

        //test1 should be an empty set
        assertTrue(test1.equals(test3));
    }

    @Test
    public void test_Difference_Routine(){
        ISet<Integer> test1 = MakeASet();
        ISet<Integer> test2 = MakeASet();
        ISet<Integer> test3 = MakeASet();

        for(int i = 1; i < 5; i++){
            test1.add(i);
        }

        for(int i = 3; i < 7; i++){
            test2.add(i);
        }

        test1.difference(test2);

        test3.add(1);
        test3.add(2);

        assertTrue(test1.equals(test3));
    }

}